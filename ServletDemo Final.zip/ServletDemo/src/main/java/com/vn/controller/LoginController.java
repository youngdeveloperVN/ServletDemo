package com.vn.controller;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vn.consts.Consts;
import com.vn.model.UserInfo;
import com.vn.service.UserService;

@WebServlet("/login")
public class LoginController extends HttpServlet {
	private static final long serialVersionUID = 1L;
	
	private UserService userService = new UserService();
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		//TODO check login
		//
		
		String usernameRemember = "";
		Cookie[] cookies = req.getCookies();
		for (Cookie cookie : cookies) {
			String name = cookie.getName();
			if("uname".equals(name)) {
				usernameRemember = cookie.getValue();
			}
		}
		req.setAttribute("uname", usernameRemember);
		req.getRequestDispatcher("login.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// get param form input form
		String username = req.getParameter("username");
		String password = req.getParameter("password");

		// 2. validate data

		// 3. check username and password => DB
		UserInfo user = userService.checkLogin(username, password);
		if (user != null) {
			req.getSession().setAttribute(Consts.USER_LOGGED, user);
			Cookie cookie = new Cookie("uname", username);
			resp.addCookie(cookie);
			resp.sendRedirect(req.getContextPath() + "/home");
		} else {
			req.setAttribute("message", "Username or password is incorrect");
			req.getRequestDispatcher("login.jsp").forward(req, resp);
		}

		// 4. Show message error
	}

}
