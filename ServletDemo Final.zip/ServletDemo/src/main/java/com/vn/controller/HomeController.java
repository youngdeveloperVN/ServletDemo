package com.vn.controller;

import java.io.IOException;

import javax.servlet.ServletConfig;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/home")
public class HomeController extends HttpServlet {
	private static final long serialVersionUID = 1L;

	@Override
	protected void service(HttpServletRequest arg0, HttpServletResponse arg1) throws ServletException, IOException {
		System.out.println("Call service......");
		super.service(arg0, arg1);
	}
	
	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Call doGet......");
		req.getRequestDispatcher("index.jsp").forward(req, resp);
	}
	
	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		System.out.println("Call doPost......");
		super.doPost(req, resp);
	}
	
	@Override
	public void init(ServletConfig config) throws ServletException {
		String username = config.getServletContext().getInitParameter("username");
		String password = config.getServletContext().getInitParameter("password");
		
		
		System.out.println("Call init......");
		System.out.println("Param......: " + username);
		System.out.println("Param......: " + password);
		super.init(config);
	}
	
	@Override
	public void destroy() {
		System.out.println("Call destroy......");
		super.destroy();
	}
	
}
