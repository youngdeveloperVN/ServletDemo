package com.vn.service;

import java.util.ArrayList;

import com.vn.model.UserInfo;

public class UserService {

	public UserInfo checkLogin(String userame, String password) {
		// SELECT * FROM WHERE USERNAME = userame AND PASSWORD = password
		UserInfo info = new UserInfo(userame, password, "", "ngochuy.mmt@gmail.com");
		
		ArrayList<String> roles = new ArrayList<String>();
		roles.add("MEMBER");
		if (userame.equals("ngochuy.mmt@gmail.com")) {
			roles.add("ADMIN_ROLE");
		} 
		info.setRoles(roles);
		return info;
	}

}
