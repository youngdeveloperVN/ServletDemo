package com.vn.listener;

import javax.servlet.ServletContext;
import javax.servlet.annotation.WebListener;
import javax.servlet.http.HttpSessionEvent;
import javax.servlet.http.HttpSessionListener;

@WebListener
public class CountUserListener implements HttpSessionListener {
	
	private ServletContext context = null;
	private int totalUser = 0;
	private int currentUser = 0;
	
	@Override
	public void sessionCreated(HttpSessionEvent se) {
		
		System.out.println("Event sessionCreated....." + se.getSession().getId());
		
		totalUser++;
		currentUser++;
		
		context = se.getSession().getServletContext();
		context.setAttribute("totalUser", totalUser);
		context.setAttribute("currentUser", currentUser);
	}
	
	@Override
	public void sessionDestroyed(HttpSessionEvent se) {
		
		System.out.println("Event sessionDestroyed....." + se.getSession().getId());
		
		currentUser--;
		context.setAttribute("currentUser", currentUser);
	}

}
