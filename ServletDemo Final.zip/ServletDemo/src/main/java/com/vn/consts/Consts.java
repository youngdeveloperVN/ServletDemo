package com.vn.consts;

public class Consts {

	public static final String USER_LOGGED = "USER_LOGGED";
	public static final String ADMIN_ROLE = "ADMIN_ROLE";
}
