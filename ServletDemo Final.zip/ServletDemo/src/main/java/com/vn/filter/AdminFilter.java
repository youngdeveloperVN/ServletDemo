package com.vn.filter;

import java.io.IOException;
import java.util.List;
import java.util.stream.Collectors;

import javax.servlet.DispatcherType;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.ServletRequest;
import javax.servlet.ServletResponse;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vn.consts.Consts;
import com.vn.model.UserInfo;

@WebFilter(urlPatterns = "/admin/*", dispatcherTypes = DispatcherType.REQUEST)
public class AdminFilter extends HttpFilter {
	private static final long serialVersionUID = 1L;

	@Override
	public void doFilter(ServletRequest servletRequest, ServletResponse servletResponse, FilterChain chain)
			throws IOException, ServletException {
		
		HttpServletRequest request = (HttpServletRequest) servletRequest;
		HttpServletResponse response = (HttpServletResponse) servletResponse;

		UserInfo user = (UserInfo)request.getSession().getAttribute(Consts.USER_LOGGED);
		
		if(user==null) {
			response.sendRedirect(request.getContextPath() + "/login");
			
		} else {
			List<String> roleAdmin = user.getRoles().stream().filter(r -> {
				return Consts.ADMIN_ROLE.equals(r);
			}).collect(Collectors.toList());
			
			if(roleAdmin.size() > 0) {
				chain.doFilter(request, response);
			} else {
				response.sendRedirect(request.getContextPath() + "/home");
			} 
		}
	}

}
