package com.vn.filter;

import java.io.IOException;

import javax.servlet.DispatcherType;
import javax.servlet.FilterChain;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.vn.consts.Consts;
import com.vn.model.UserInfo;

@WebFilter(urlPatterns = {"/*"}, dispatcherTypes = DispatcherType.REQUEST)
public class AuthFilter extends HttpFilter {
	private static final long serialVersionUID = 1L;

	@Override
	protected void doFilter(HttpServletRequest request, HttpServletResponse response, FilterChain chain)
			throws IOException, ServletException {
		UserInfo user = (UserInfo) request.getSession().getAttribute(Consts.USER_LOGGED);
		
		String uri = request.getRequestURI();

		if (user == null && !uri.contains("login")) {
			response.sendRedirect(request.getContextPath() + "/login");
		} else {
			chain.doFilter(request, response);
		}
	}

}